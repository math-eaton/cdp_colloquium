# Cities and Flights Demo

Learning about creating abstractions with ChatGPT and traversing graphs. Built with P5.js.

## Easiest way to use this

Start a python server.

> python -m http.server

Then navigate to the URL it notes, most often http://localhost:8000
