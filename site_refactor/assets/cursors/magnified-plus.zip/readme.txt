﻿=== Magnified+ Cursor Set ===

By: The Derpy Girl (http://www.rw-designer.com/user/55973)

Download: http://www.rw-designer.com/cursor-set/magnified-plus

Author's description:

The finished version of Microsoft's "Magnified (system scheme)" cursor theme. They never finished it properly so I did.

To equip/use these cursors:
* Copy and paste the downloaded cursor set into a new folder in C:\Windows\Cursors. Make sure you click Continue if it requires admin privilages.
* Go to the start menu, and search for main.cpl, then hit Enter. Regardless of what version of Windows you use, the search function works the same.
* Go to the Pointers tab.
* Select the role cursor, find the matching cursor in said folder, and set it.
* Repeat for the other 16 roles.
* Save the cursor theme by clicking Save As... and name it whatever you wish.
* Click OK or Apply and you're done!

==========

License: Creative Commons - Attribution + Noncommercial

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.
* Noncommercial - You may not use this work for commercial purposes.